<!-- Start Testimonials
    ============================================= -->
    <div class="pricing-area bg-gray default-padding">
        <div class="shape-animation">
            <img src="assets/img/shape/anim-1.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row align-center">
                <div class="testimonial-style-one col-xl-4 col-lg-5">
                    <h4 class="sub-heading">Testimonials</h4>
                    <h2 class="heading">What customers feedback about us</h2>
                    <div class="rating-provider">
                        <div class="thumb">
                            <img src="assets/img/t1.webp" alt="Image Not Found">
                            <img src="assets/img/t2.webp" alt="Image Not Found">
                            <img src="assets/img/t3.webp" alt="Image Not Found">
                            <img src="assets/img/t4.webp" alt="Image Not Found">
                        </div>
                        <div class="ratings">
                            <div class="rating-icon">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <h4>(4.8/5)</h4>
                            </div>
                            <span>Based on 1,258 reviews</span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-style-one pl-65 pl-md-15 pl-xs-15 col-xl-8 col-lg-7">
                    <div class="shape-right-bottom">
                        <img src="assets/img/shape/anim-2.png" alt="Image not found">
                    </div>

                    <div class="testimonial-style-one-carousel swiper">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one-item">
                                    <div class="quote-icon">
                                        <img src="assets/img/quote.png" alt="quote">
                                    </div>
                                    <div class="item">

                                        <div class="provider">
                                            <div class="info">
                                                <h4>Businss Growth</h4>
                                                <span><strong>JURGEN K.</strong> / Senior Marketer</span>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <p align="justify">
                                            UltraGITS has been a game-changer for our business. Their strategic digital marketing approach significantly boosted our brand visibility and online engagement. The team is professional, attentive, and always delivers on time. We highly recommend UltraGITS to any business looking to grow effectively in the digital space.
                                            </p>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one-item">
                                    <div class="quote-icon">
                                        <img src="assets/img/quote.png" alt="quote">
                                    </div>
                                    <div class="item">


                                        <div class="provider">
                                            <div class="info">
                                                <h4>Professional SEO</h4>
                                                <span><strong>ANTHO.</strong> / Businessman</span>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <p align="justify">
                                            Working with UltraGITS was a seamless experience. Their team took time to understand our goals and delivered a powerful marketing plan. We’ve seen a measurable increase in traffic and leads since partnering with them. Their experience and dedication make them one of the top digital agencies in Chennai.
                                            </p>
                                        </div>


                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one-item">
                                    <div class="quote-icon">
                                        <img src="assets/img/quote.png" alt="quote">
                                    </div>
                                    <div class="item">

                                        <div class="provider">
                                            <div class="info">
                                                <h4>Website Performance</h4>
                                                <span><strong>METHO K.</strong> / Developer</span>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <p align="justify">
                                            We chose UltraGITS for their expertise and they didn’t disappoint. Their targeted campaigns, creative content, and continuous optimization have elevated our brand online. It’s rare to find a team this committed and skilled. They are truly a trusted digital marketing partner for any business looking to grow.
                                            </p>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Testimonials -->
