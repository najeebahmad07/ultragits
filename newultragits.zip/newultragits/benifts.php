
    <!-- Start Business Progress
    ============================================= -->
    <div class="business-progress-area default-padding">
        <div class="container">
            <div class="row align-center">

                <div class="col-xl-6 col-lg-5">
                    <div class="business-progress-thumb">
                        <img src="assets/img/illustration/13.png" alt="Image Not Found">
                        <div class="fun-fact">
                            <div class="counter">
                                <div class="timer" data-to="5" data-speed="5000">5</div>
                                <div class="operator">K+</div>
                            </div>
                            <span class="medium">Completed Project</span>
                        </div>
                    </div>
                </div>

                <div class="col-xl-5 offset-xl-1 col-lg-6 offset-lg-1">
                    <div class="business-progress-info">
                        <h2 class="title">Benifts UltraGITS for Digital Marketing</h2>
                        <div class="list-grid-info">
                            <ul>
                                <li>
                                    <h4>Business Integration</h4>
                                </li>
                                <li>Customized strategies for each business goals</li>
                                <li>20+ years of industry experience</li>
                                <li>Best online marketing agency in Chennai</li>
                                <li>Affordable Digital marketing Service in Chennai</li>
                                <li>Scalable solutions for startups, SMEs, and enterprises</li>
                            </ul>
                            <ul>
                                <li><h4>Business Development </h4></li>
                                <li>Branding Solution across the targeted location</li>
                                <li>Advanced Digital Marketing Agency in Chennai</li>
                                <li>Affordable, flexible packages with measurable growth</li>
                                <li>Local to international Expertise</li>
                                <li>Healthcare & Hospitality Facility</li>
                            </ul>
                        </div>
                        <div class="skill-items style-two mt-30">
                            <!-- Progress Bar Start -->
                            <div class="progress-box">
                                <h5>Business Growth</h5>
                                <div class="progress">
                                    <div class="progress-bar" role="progressbar" data-width="98">
                                            <span>98%</span>
                                    </div>
                                </div>
                            </div>
                            <!-- End Progressbar -->
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Business Progress -->