
    <!-- Start Projects
    ============================================= -->
    <div class="project-area default-padding">
        <!-- Shape -->
        <div class="shape-left-bottom" style="background-image: url(assets/img/shape/21.png);"></div>
        <!-- End Shape -->
        <!-- Shape -->
        <div class="shape-right-top" style="background-image: url(assets/img/shape/22.png);"></div>
        <!-- End Shape -->
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-title">Previous Projects</h4>
                        <h2 class="title">Our Featured Projects</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="projects-box">

                <div class="row">

                    <div class="col-lg-12">
                        <div class="row">
                            <!-- Single Item -->
                            <div class="col-lg-4 col-md-6 single-item">
                                <div class="project-style-one">
                                    <div class="thumb">
                                        <img src="assets/img/case/1.jpg" alt="Thumb">
                                    </div>
                                    <div class="content">
                                        <a class="button" href="project-details.html"><i class="fas fa-angle-right"></i></a>
                                        <h4><a href="project-details.html">Community Engagement</a></h4>
                                        <ul>
                                            <li>
                                                Marketing
                                            </li>
                                            <li>
                                                Sales
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                            <!-- Single Item -->
                            <div class="col-lg-4 col-md-6 single-item">
                                <div class="project-style-one">
                                    <div class="thumb">
                                        <img src="assets/img/case/5.jpg" alt="Thumb">
                                    </div>
                                    <div class="content">
                                        <a class="button" href="project-details.html"><i class="fas fa-angle-right"></i></a>
                                        <h4><a href="project-details.html">Traffic Management</a></h4>
                                        <ul>
                                            <li>
                                                Profit
                                            </li>
                                            <li>
                                                Increment
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                            <!-- Single Item -->
                            <div class="col-lg-4 col-md-6 single-item">
                                <div class="project-style-one">
                                    <div class="thumb">
                                        <img src="assets/img/case/8.jpg" alt="Thumb">
                                    </div>
                                    <div class="content">
                                        <a class="button" href="project-details.html"><i class="fas fa-angle-right"></i></a>
                                        <h4><a href="project-details.html">Income growth</a></h4>
                                        <ul>
                                            <li>
                                                Management
                                            </li>
                                            <li>
                                                Advertising
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Item -->
                        </div>
                    </div>

                    <div class="col-lg-12 mt-50 mt-xs-0 mt-md-20">
                        <div class="project-more-info">
                            <div class="row">
                                <div class="col-xl-4 col-lg-4">
                                    <h2>Are You ready to grow <br> your businesses </h2>
                                </div>
                                <div class="col-xl-5 col-lg-4 pl-35 pl-md-15 pl-xs-15">
                                    <p>
                                        There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, simply free text by injected humour, or randomised.
                                    </p>
                                </div>
                                <div class="col-xl-3 col-lg-4">
                                    <a class="btn btn-md btn-gradient animation" href="project.html">Get A Proposal <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End Projects -->
